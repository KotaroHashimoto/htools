package org.knime.workshop.exercise.exercise05;

import javax.swing.JPanel;
import javax.swing.JTextField;

import org.knime.core.data.DataTableSpec;
import org.knime.core.data.StringValue;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeDialogPane;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;
import org.knime.core.node.NotConfigurableException;
import org.knime.core.node.defaultnodesettings.DefaultNodeSettingsPane;
import org.knime.core.node.defaultnodesettings.DialogComponentColumnNameSelection;
import org.knime.core.node.defaultnodesettings.SettingsModelString;

/**
 * <code>NodeDialog</code> for the "Concatenate2Columns" Node. This node
 * concatenates two columns.
 *
 * This node dialog derives from {@link DefaultNodeSettingsPane} which allows
 * creation of a simple dialog with standard components. If you need a more
 * complex dialog please derive directly from
 * {@link org.knime.core.node.NodeDialogPane}.
 * 
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeDialog extends NodeDialogPane {
	
	private final JPanel m_firstColumnSelectorPanel;
	private final DialogComponentColumnNameSelection m_firstColumnSelector;
	
	private final JPanel m_secondColumnSelectorPanel;
	private final DialogComponentColumnNameSelection m_secondColumnSelector;
	
	private final JTextField m_setNewColumnName;

	private final String m_labelFormat = "%-20s";
	
	/**
	 * New pane for configuring Concatenate2Columns node dialog. This is just a
	 * suggestion to demonstrate possible default dialog components.
	 */
	protected ConcatenateTwoColumnsNodeDialog() {
		super();
		
		/*
		 *  Setup all member variables and panels
		 */
		
		m_firstColumnSelectorPanel = null;
		m_firstColumnSelector = null;
		m_secondColumnSelectorPanel = null;
		m_secondColumnSelector = null;
		m_setNewColumnName = null;
		
		
		/*
		 * Organize layout
		 */
		
		
		JPanel tabPanel = null;
		addTab("Column Selection", tabPanel );
	}


	@SuppressWarnings("unchecked")
	private DialogComponentColumnNameSelection getFirstColumnSelector() {
		return
			new DialogComponentColumnNameSelection(
				new SettingsModelString(
					ConcatenateTwoColumnsConfiguration.CFG_KEY_COL1, 
					ConcatenateTwoColumnsConfiguration.DEFAULT_COL1
				), 
				String.format(m_labelFormat, "First column:"), 
				0, 
				StringValue.class
			);
	}
	
	@SuppressWarnings("unchecked")
	private DialogComponentColumnNameSelection getSecondColumnSelector() {
		return
			new DialogComponentColumnNameSelection(
				new SettingsModelString(
					ConcatenateTwoColumnsConfiguration.CFG_KEY_COL2, 
					ConcatenateTwoColumnsConfiguration.DEFAULT_COL2
				), 
				String.format(m_labelFormat, "Second column:"), 
				0, 
				StringValue.class
			);
	}

	@Override
	protected void saveSettingsTo(NodeSettingsWO settings) throws InvalidSettingsException {
		
		// TODO: use a new configuration object to save settings from member variables
		
	}
	
	@Override
	protected void loadSettingsFrom(NodeSettingsRO settings, DataTableSpec[] specs) throws NotConfigurableException {
		ConcatenateTwoColumnsConfiguration config;
		try {
			config = new ConcatenateTwoColumnsConfiguration().loadInDialog(settings);;
        } catch (InvalidSettingsException e) {
            throw new NotConfigurableException("Could not load settings in dialog", e);
        }
		
		// TODO: use a new configuration object to load settings and set them to the member variables

	}
	
}
