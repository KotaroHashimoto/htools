package org.knime.workshop.exercise.exercise05;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpec;
import org.knime.core.data.DataColumnSpecCreator;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.DataType;
import org.knime.core.data.StringValue;
import org.knime.core.data.def.DefaultRow;
import org.knime.core.data.def.StringCell;
import org.knime.core.node.BufferedDataContainer;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;

/**
 * This is the model implementation of Concatenate Two First String Columns. This node
 * concatenates the two first string columns and adds the result to the input table.
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeModel extends NodeModel {
	
	private final ConcatenateTwoColumnsConfiguration m_configuration;
	
	/*
	 * TODO: Replace the hard coded member variables with the corresponding fields in the configuration object.
	 * 
	 * Hint: Delete the three following member variables to localize where in the code changes need to be made
	 */
	private final String firstColumn = "";
	private final String secondColumn = "";
	private final String newName = "";

	
	
	
	/**
	 * Constructor for the node model.
	 */
	protected ConcatenateTwoColumnsNodeModel() {
		super(1, 1);
		m_configuration = new ConcatenateTwoColumnsConfiguration();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		// Call for validation of configuration against incoming spec.
		findAndValidateSelectedColumnIndices(inSpecs[0]);
		return new DataTableSpec[]{createOutSpec(inSpecs[0])};
	}
	
	private DataTableSpec createOutSpec(final DataTableSpec inSpec) throws InvalidSettingsException {
		DataColumnSpec concatenateColumnSpec = 
			new DataColumnSpecCreator(
				newName, 
				StringCell.TYPE
			).createSpec();
		return new DataTableSpec(inSpec, new DataTableSpec(concatenateColumnSpec));
	}
	
	private int[] findAndValidateSelectedColumnIndices(final DataTableSpec spec) throws InvalidSettingsException {
		String first = firstColumn;
		String second = secondColumn;
		if (first == null || second == null) {
			throw new InvalidSettingsException("Not configured yet");
		}
		int firstIndex = spec.findColumnIndex(first);
		int secondIndex = spec.findColumnIndex(second);
		if (firstIndex < 0) {
			throw new InvalidSettingsException("No such column in input table: " + first);
		}
		if (secondIndex < 0) {
			throw new InvalidSettingsException("No such column in input table: " + second);
		}
		DataType firstType = spec.getColumnSpec(firstIndex).getType();
		DataType secondType = spec.getColumnSpec(secondIndex).getType();
		if (!firstType.isCompatible(StringValue.class)) {
			throw new InvalidSettingsException("Column '" + first + "' does not contain strings");
		}
		if (!secondType.isCompatible(StringValue.class)) {
			throw new InvalidSettingsException("Column '" + second + "' does not contain strings");
		}
		return new int[] { firstIndex, secondIndex };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BufferedDataTable[] execute(final BufferedDataTable[] inData, final ExecutionContext exec)
			throws Exception {
		DataTableSpec inTableSpec = inData[0].getDataTableSpec();
		DataTableSpec newTableSpec = createOutSpec(inTableSpec);
		BufferedDataContainer dc = exec.createDataContainer(newTableSpec);

		int nrCols = newTableSpec.getNumColumns();
		int[] selectedColumnIndices = findAndValidateSelectedColumnIndices(newTableSpec);
        for (DataRow row : inData[0]) {
            DataCell[] copyRow = new DataCell[nrCols];
            for (int j = 0; j < nrCols - 1; j++) {
                copyRow[j] = row.getCell(j);
            }

            DataCell firstCell = copyRow[selectedColumnIndices[0]];
            DataCell secondCell = copyRow[selectedColumnIndices[1]];
            if (!firstCell.isMissing() && !secondCell.isMissing()) {
            	String firstColumnString = ((StringValue) firstCell).getStringValue();
            	String secondColumnString  = ((StringValue) secondCell).getStringValue();
            	String output = firstColumnString + " + " + secondColumnString;
            	copyRow[nrCols - 1] = new StringCell(output);
            } else {
            	copyRow[nrCols - 1] = DataType.getMissingCell();
            }
            
            dc.addRowToTable(new DefaultRow(row.getKey(), copyRow));
            exec.setProgress(dc.size() / (double) inData[0].size());
        }
        dc.close();
        return new BufferedDataTable[]{dc.getTable()};	
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {

		// TODO: Use configuration objects method

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {
		
		// TODO: Use configuration objects method
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {

		// TODO: Use configuration objects method

	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

}
