package org.knime.workshop.exercise.exercise03_b.node.gps;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpec;
import org.knime.core.data.DataColumnSpecCreator;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.DoubleValue;
import org.knime.core.data.def.DefaultRow;
import org.knime.core.data.def.IntCell;
import org.knime.core.node.BufferedDataContainer;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;

public class GPSExampleNodeNodeModel extends NodeModel {

	/**
	 * Constructor for the node model.
	 */
	protected GPSExampleNodeNodeModel() {
		super(1, 1);
	}

	private DataColumnSpec createGPSColSpec() {
		// TODO Change TYPE to GPS-Type. Look at IntCell.TYPE to see how that's done
		return new DataColumnSpecCreator("GPS Coordinates", IntCell.TYPE).createSpec();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BufferedDataTable[] execute(final BufferedDataTable[] inData, final ExecutionContext exec)
			throws Exception {
		DataTableSpec inTableSpec = inData[0].getDataTableSpec();

		DataColumnSpec[] allColSpecs = new DataColumnSpec[inTableSpec.getNumColumns() - 1];
		int longitudeIndex = -1;
		int latitudeIndex = -1;
		int pointer = 0;
		for (int i = 0; i < allColSpecs.length; i++) {
			DataColumnSpec columnSpec = inTableSpec.getColumnSpec(i);
			if ("Longitude".equals(columnSpec.getName())) {
				longitudeIndex = i;
			} else if ("Latitude".equals(columnSpec.getName())) {
				latitudeIndex = i;
			} else {
				allColSpecs[pointer] = columnSpec;
				pointer++;
			}
		}

		allColSpecs[allColSpecs.length - 1] = createGPSColSpec();

		DataTableSpec outputSpec = new DataTableSpec(allColSpecs);
		BufferedDataContainer container = exec.createDataContainer(outputSpec);
		for (DataRow inRow : inData[0]) {
			DataCell[] cells = new DataCell[outputSpec.getNumColumns()];
			pointer = 0;
			for (int i = 0; i < inRow.getNumCells(); i++) {
				if (i != longitudeIndex && i != latitudeIndex) {
					cells[pointer] = inRow.getCell(i);
				}
			}

			double longitude = ((DoubleValue) inRow.getCell(longitudeIndex)).getDoubleValue();
			double latitude = ((DoubleValue) inRow.getCell(latitudeIndex)).getDoubleValue();
			// TODO Create GPS cell
			// cells[row.getNumCells()-1] = new GPSDataCell(...);

			DataRow outRow = new DefaultRow(inRow.getKey(), cells);
			container.addRowToTable(outRow);
		}
		container.close();
		BufferedDataTable out = container.getTable();
		return new BufferedDataTable[] { out };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		DataColumnSpec[] allColSpecs = new DataColumnSpec[inSpecs[0].getNumColumns() - 1];
		boolean longitude = false;
		boolean latitude = false;
		int pointer = 0;
		for (int i = 0; i < allColSpecs.length; i++) {
			DataColumnSpec columnSpec = inSpecs[0].getColumnSpec(i);
			if ("Longitude".equals(columnSpec.getName())) {
				longitude = true;
			} else if ("Latitude".equals(columnSpec.getName())) {
				latitude = true;
			} else {
				allColSpecs[pointer] = columnSpec;
				pointer++;
			}
		}
		allColSpecs[allColSpecs.length - 1] = createGPSColSpec();
		if (!longitude || !latitude) {
			throw new InvalidSettingsException(
					"Input needs two double-compatible columns \"Longitude\" and a column \"Latitude\"");
		}
		return new DataTableSpec[] { new DataTableSpec(allColSpecs) };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {

	}

}
