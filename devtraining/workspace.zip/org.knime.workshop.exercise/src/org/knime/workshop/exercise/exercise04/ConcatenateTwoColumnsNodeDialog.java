package org.knime.workshop.exercise.exercise04;

import org.knime.core.node.defaultnodesettings.DefaultNodeSettingsPane;

/**
 * <code>NodeDialog</code> for the "Concatenate2Columns" Node. This node
 * concatenates two columns.
 *
 * This node dialog derives from {@link DefaultNodeSettingsPane} which allows
 * creation of a simple dialog with standard components. If you need a more
 * complex dialog please derive directly from
 * {@link org.knime.core.node.NodeDialogPane}.
 * 
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeDialog extends DefaultNodeSettingsPane {

	/**
	 * New pane for configuring Concatenate2Columns node dialog. This is just a
	 * suggestion to demonstrate possible default dialog components.
	 */
	protected ConcatenateTwoColumnsNodeDialog() {
		super();

		/*
		 * Hint: addDialogComponent(new DialogComponentColumnNameSelection(Fill in));
		 */

	}

	
	// TODO create static factory methods for all settings models
	
}
