package org.knime.workshop.exercise.exercise03_b.datatype.gps;

public interface GPSDataValue {

	/*
	 * Define the getter-methods needed for a GPS value and extend the DataValue
	 * interface.
	 */

}
