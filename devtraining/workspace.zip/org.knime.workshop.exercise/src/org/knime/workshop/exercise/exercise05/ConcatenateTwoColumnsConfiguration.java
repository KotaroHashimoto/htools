package org.knime.workshop.exercise.exercise05;

import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;

public class ConcatenateTwoColumnsConfiguration {
	
	public static final String CFG_KEY_COL1 = "first_column_name";
	public static final String CFG_KEY_COL2 = "second_column_name";
	public static final String CFG_KEY_NEW_NAME = "new_name";
	
	public static final String DEFAULT_COL1 = "";
	public static final String DEFAULT_COL2 = "";
	public static final String DEFAULT_NEW_NAME = "Concatenate";
	
	private String m_firstColumnName;
	private String m_secondColumnName;
	private String m_newColumnName;
	
	public String getFirstColumnName() {
		return m_firstColumnName;
	}
	
	public void setFirstColumnName(String firstColumnName) {
		m_firstColumnName = firstColumnName;
	}
	
	public String getSecondColumnName() {
		return m_secondColumnName;
	}
	
	public void setSecondColumnName(String secondColumnName) {
		m_secondColumnName = secondColumnName;
	}
	
	public String getNewColumnName() {
		return m_newColumnName;
	}
	
	public void setNewColumnName(String newColumnName) {
		m_newColumnName = newColumnName;
	}
	
	public ConcatenateTwoColumnsConfiguration saveSettingsTo(NodeSettingsWO settings) {

		// TODO: Implement
		
		return this;
	}
	
	public ConcatenateTwoColumnsConfiguration loadInDialog(NodeSettingsRO settings) throws InvalidSettingsException {
		
		// TODO: Implement

		return this;
	}
	
	public ConcatenateTwoColumnsConfiguration loadInModel(NodeSettingsRO settings) throws InvalidSettingsException {
		
		// TODO: Implement
		
		return this;
	}
	
	public ConcatenateTwoColumnsConfiguration validate(NodeSettingsRO settings) throws InvalidSettingsException {
		
		// TODO: Implement
		
		return this;
	}

}
