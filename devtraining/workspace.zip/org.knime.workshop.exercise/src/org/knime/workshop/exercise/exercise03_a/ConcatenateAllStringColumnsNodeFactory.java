package org.knime.workshop.exercise.exercise03_a;

import org.knime.core.node.NodeDialogPane;
import org.knime.core.node.NodeFactory;
import org.knime.core.node.NodeView;

/**
 * <code>NodeFactory</code> for the "Concatenate All Strings" Node.
 * This node concatenates all string input columns and adds the result to the input table
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateAllStringColumnsNodeFactory 
        extends NodeFactory<ConcatenateAllStringColumnsNodeModel> {

    /**
     * {@inheritDoc}
     */
    @Override
    public ConcatenateAllStringColumnsNodeModel createNodeModel() {
        return new ConcatenateAllStringColumnsNodeModel();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getNrNodeViews() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeView<ConcatenateAllStringColumnsNodeModel> createNodeView(final int viewIndex,
            final ConcatenateAllStringColumnsNodeModel nodeModel) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasDialog() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeDialogPane createNodeDialogPane() {
        return null;
    }

}

