package org.knime.workshop.exercise.exercise06;

import org.knime.core.node.NodeDialogPane;
import org.knime.core.node.NodeFactory;
import org.knime.core.node.NodeView;

/**
 * <code>NodeFactory</code> for the "ConcatenateEverything" Node.
 * This node concatenates all input columns and adds the result to the input table
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeFactory 
        extends NodeFactory<ConcatenateTwoColumnsNodeModel> {

    /**
     * {@inheritDoc}
     */
    @Override
    public ConcatenateTwoColumnsNodeModel createNodeModel() {
        return new ConcatenateTwoColumnsNodeModel();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getNrNodeViews() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeView<ConcatenateTwoColumnsNodeModel> createNodeView(final int viewIndex,
            final ConcatenateTwoColumnsNodeModel nodeModel) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasDialog() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeDialogPane createNodeDialogPane() {
        return new ConcatenateTwoColumnsNodeDialog();
    }

}

