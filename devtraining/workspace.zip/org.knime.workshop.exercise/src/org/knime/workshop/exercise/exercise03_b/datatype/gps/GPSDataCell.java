package org.knime.workshop.exercise.exercise03_b.datatype.gps;

public class GPSDataCell {

	// TODO make final
	private double longitude;
	private double latitude;

	/*
	 * TODO:
	 * 
	 * Extend the GPSDataValue interface and other existing and compatible DataValue
	 * interfaces (i.e. StringValue) to create a KNIME data type from this class
	 * 
	 */

}
