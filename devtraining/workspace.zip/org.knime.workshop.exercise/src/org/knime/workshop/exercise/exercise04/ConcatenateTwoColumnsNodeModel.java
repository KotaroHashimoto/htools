package org.knime.workshop.exercise.exercise04;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpec;
import org.knime.core.data.DataColumnSpecCreator;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.StringValue;
import org.knime.core.data.def.DefaultRow;
import org.knime.core.data.def.StringCell;
import org.knime.core.node.BufferedDataContainer;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;

/**
 * This is the model implementation of Concatenate Two String Columns. This node
 * concatenates two string columns and adds the result to the input table.
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeModel extends NodeModel {

	
	/* TODO: Use the static settings model factory methods in the dialog to instantiate the settings models 
	
	private final SettingsModelString m_col1 = null;
	private final SettingsModelString m_col2 = null;
	private final SettingsModelString m_newName = null;
	
	*/

	/**
	 * Constructor for the node model.
	 */
	protected ConcatenateTwoColumnsNodeModel() {
		super(1, 1);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		DataTableSpec outputSpec = createOutputSpec(inSpecs[0]);
		return new DataTableSpec[]{outputSpec};
	}
	
	private DataTableSpec createOutputSpec(final DataTableSpec inSpec) throws InvalidSettingsException {
		
		// TODO: Replace hard-coded column name with configured name in SettingsModel
		
		String concatenateColumnName = "Concatenate";
		DataColumnSpec concatenateColumnSpec = 
			new DataColumnSpecCreator(
				concatenateColumnName, 
				StringCell.TYPE
			).createSpec();
		return new DataTableSpec(inSpec, new DataTableSpec(concatenateColumnSpec));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BufferedDataTable[] execute(final BufferedDataTable[] inData, final ExecutionContext exec)
			throws Exception {
		DataTableSpec inTableSpec = inData[0].getDataTableSpec();
		DataTableSpec outputTableSpec = createOutputSpec(inTableSpec);
		BufferedDataContainer dataContainer = exec.createDataContainer(outputTableSpec);

		int nrInputColumns = inTableSpec.getNumColumns();
		boolean[] isStringCompatible = new boolean[nrInputColumns];
		for (int i = 0; i < nrInputColumns; i++) {
			DataColumnSpec columnSpec = inTableSpec.getColumnSpec(i);
			isStringCompatible[i] = columnSpec.getType().isCompatible(StringValue.class);
		}
		
		int nrOutputColumns = nrInputColumns + 1;
        for (DataRow row : inData[0]) {
            // Copy cells to new row
        	DataCell[] copyRow = new DataCell[nrOutputColumns];
            for (int j = 0; j < nrInputColumns; j++) {
                copyRow[j] = row.getCell(j);
            }
            
            // Concatenate all string cells
            StringBuilder concatenated = new StringBuilder();

            
            // TODO: Use the SettingsModel to find the columns that should be concatenated
            
            
            
            copyRow[nrOutputColumns -1] = new StringCell(concatenated.toString()); 
            dataContainer.addRowToTable(new DefaultRow(row.getKey(), copyRow));
            exec.setProgress(dataContainer.size() / (double) inData[0].size());
        }
        dataContainer.close();
        return new BufferedDataTable[]{dataContainer.getTable()};	
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {
		
		// TODO: implement using the settings models
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {

		// TODO: implement using the settings models
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {

		// TODO: implement using the settings models
		
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

}
