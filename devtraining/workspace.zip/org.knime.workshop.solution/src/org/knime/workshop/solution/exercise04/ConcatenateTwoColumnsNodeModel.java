package org.knime.workshop.solution.exercise04;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpec;
import org.knime.core.data.DataColumnSpecCreator;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.DataType;
import org.knime.core.data.StringValue;
import org.knime.core.data.def.DefaultRow;
import org.knime.core.data.def.StringCell;
import org.knime.core.node.BufferedDataContainer;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;
import org.knime.core.node.defaultnodesettings.SettingsModelString;

/**
 * This is the model implementation of Concatenate Two First String Columns. This node
 * concatenates the two first string columns and adds the result to the input table.
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeModel extends NodeModel {

	private final SettingsModelString m_col1 = ConcatenateTwoColumnsNodeDialog.createFirstColumnModel();
	private final SettingsModelString m_col2 = ConcatenateTwoColumnsNodeDialog.createSecondColumnModel();
	private final SettingsModelString m_newName = ConcatenateTwoColumnsNodeDialog.createNewColumnNameModel();

	/**
	 * Constructor for the node model.
	 */
	protected ConcatenateTwoColumnsNodeModel() {
		super(1, 1);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		// Call for validation of configuration against incoming spec.
		findAndValidateSelectedColumnIndices(inSpecs[0]);
		return new DataTableSpec[]{createOutSpec(inSpecs[0])};
	}
	
	private int[] findAndValidateSelectedColumnIndices(final DataTableSpec spec) throws InvalidSettingsException {
		String firstColumn = m_col1.getStringValue();
		String secondColumn = m_col2.getStringValue();
		
		if (isBlank(firstColumn) || isBlank(secondColumn)) {
			throw new InvalidSettingsException("Not configured yet");
		}
		int firstIndex = spec.findColumnIndex(firstColumn);
		int secondIndex = spec.findColumnIndex(secondColumn);
		if (firstIndex < 0) {
			throw new InvalidSettingsException("No such column in input table: " + firstColumn);
		}
		if (secondIndex < 0) {
			throw new InvalidSettingsException("No such column in input table: " + secondColumn);
		}
		DataType firstType = spec.getColumnSpec(firstIndex).getType();
		DataType secondType = spec.getColumnSpec(secondIndex).getType();
		if (!firstType.isCompatible(StringValue.class)) {
			throw new InvalidSettingsException("Column '" + firstColumn + "' does not contain strings");
		}
		if (!secondType.isCompatible(StringValue.class)) {
			throw new InvalidSettingsException("Column '" + secondColumn + "' does not contain strings");
		}
		return new int[] { firstIndex, secondIndex };
	}
	
	private boolean isBlank(String str) {
		return str == null || str.isEmpty();
	}
	
	private DataTableSpec createOutSpec(final DataTableSpec inSpec) throws InvalidSettingsException {
		DataColumnSpec concatenateColumnSpec = 
			new DataColumnSpecCreator(
				m_newName.getStringValue(), 
				StringCell.TYPE
			).createSpec();
		return new DataTableSpec(inSpec, new DataTableSpec(concatenateColumnSpec));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BufferedDataTable[] execute(final BufferedDataTable[] inData, final ExecutionContext exec)
			throws Exception {
		DataTableSpec inTableSpec = inData[0].getDataTableSpec();
		DataTableSpec outTableSpec = createOutSpec(inTableSpec);
		BufferedDataContainer dc = exec.createDataContainer(outTableSpec);

		int nrCols = outTableSpec.getNumColumns();
		int[] selectedColumnIndices = findAndValidateSelectedColumnIndices(outTableSpec);
        for (DataRow row : inData[0]) {
        	// Copy cells to new row
        	DataCell[] copyRow = new DataCell[nrCols];
            for (int j = 0; j < nrCols - 1; j++) {
                copyRow[j] = row.getCell(j);
            }

            // Concatenate the two first string cells if present
            DataCell firstCell = copyRow[selectedColumnIndices[0]];
            DataCell secondCell = copyRow[selectedColumnIndices[1]];
            if (!firstCell.isMissing() && !secondCell.isMissing()) {
            	String firstColumnString = ((StringValue) firstCell).getStringValue();
            	String secondColumnString  = ((StringValue) secondCell).getStringValue();
            	String output = firstColumnString + " + " + secondColumnString;
            	copyRow[nrCols - 1] = new StringCell(output);
            } else {
            	copyRow[nrCols - 1] = DataType.getMissingCell();
            }
            
            dc.addRowToTable(new DefaultRow(row.getKey(), copyRow));
            exec.setProgress(dc.size() / (double) inData[0].size());
        }
        dc.close();
        return new BufferedDataTable[]{dc.getTable()};	
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {
		m_col1.saveSettingsTo(settings);
		m_col2.saveSettingsTo(settings);
		m_newName.saveSettingsTo(settings);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {
		m_col1.loadSettingsFrom(settings);
		m_col2.loadSettingsFrom(settings);
		m_newName.loadSettingsFrom(settings);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {
		m_col1.validateSettings(settings);
		m_col2.validateSettings(settings);
		m_newName.validateSettings(settings);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

}
