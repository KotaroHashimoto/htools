package org.knime.workshop.solution.exercise02;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpec;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.container.CloseableRowIterator;
import org.knime.core.data.def.DefaultRow;
import org.knime.core.node.BufferedDataContainer;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;

/**
 * This is the model implementation of the Copy Node. This node
 * concatenates all input columns and adds the result to the input table
 *
 * @author KNIME.com GmbH
 */
public class CopyNodeModel extends NodeModel {

	/**
	 * Constructor for the node model.
	 */
	protected CopyNodeModel() {
		super(1, 1);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BufferedDataTable[] execute(final BufferedDataTable[] inData, final ExecutionContext exec)
			throws Exception {
		DataTableSpec dataTableSpec = inData[0].getDataTableSpec();
		DataTableSpec newDataTableSpec = copyTableSpec(dataTableSpec);

		long counter = 0;
		BufferedDataContainer dc = exec.createDataContainer(newDataTableSpec);
		try (CloseableRowIterator iterator = inData[0].iterator()) {
			while (iterator.hasNext()) {
				DataRow inputRow = iterator.next();
				DataCell[] cells = new DataCell[inputRow.getNumCells()];
				for (int col = 0; col < inputRow.getNumCells(); col++) {
					cells[col] = inputRow.getCell(col);
				}
				DefaultRow newRow = new DefaultRow(inputRow.getKey(), cells);
				dc.addRowToTable(newRow);
				exec.setProgress(
					(double) counter++ / inData[0].size(), 
					"Concatenated row " + inputRow.getKey().getString()
				);
			}
		}
		dc.close();
		return new BufferedDataTable[] { dc.getTable() };
	}

	private DataTableSpec copyTableSpec(DataTableSpec dataTableSpec) {
		DataColumnSpec[] columnSpecs = new DataColumnSpec[dataTableSpec.getNumColumns()];
		for (int col = 0; col < dataTableSpec.getNumColumns(); col++) {
			columnSpecs[col] = dataTableSpec.getColumnSpec(col);
		}
		return new DataTableSpec(columnSpecs);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		DataTableSpec dataTableSpec = inSpecs[0];
		DataTableSpec newDataTableSpec = copyTableSpec(dataTableSpec);
		return new DataTableSpec[] { newDataTableSpec };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

}
