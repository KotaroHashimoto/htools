package org.knime.workshop.solution.exercise03_b.datatype.gps;

import org.knime.core.data.DataValue;

public interface GPSDataValue extends DataValue {
	/** Derived locally. */
	public static final UtilityFactory UTILITY = new UtilityFactory() {
	};

	double getLongitude();

	double getLatitude();
}
