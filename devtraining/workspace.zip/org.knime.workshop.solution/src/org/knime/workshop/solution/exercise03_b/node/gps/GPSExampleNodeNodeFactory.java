package org.knime.workshop.solution.exercise03_b.node.gps;

import org.knime.core.node.NodeDialogPane;
import org.knime.core.node.NodeFactory;
import org.knime.core.node.NodeView;

/**
 * <code>NodeFactory</code> for the "MyExampleNode" Node.
 * This is an example node provided by KNIME.
 *
 * @author KNIME AG, Zurich, Switzerland
 */
public class GPSExampleNodeNodeFactory 
        extends NodeFactory<GPSExampleNodeNodeModel> {

    /**
     * {@inheritDoc}
     */
    @Override
    public GPSExampleNodeNodeModel createNodeModel() {
        return new GPSExampleNodeNodeModel();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getNrNodeViews() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeView<GPSExampleNodeNodeModel> createNodeView(final int viewIndex,
            final GPSExampleNodeNodeModel nodeModel) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasDialog() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeDialogPane createNodeDialogPane() {
        return null;
    }

}

