package org.knime.workshop.solution.exercise07;

import org.knime.core.data.StringValue;
import org.knime.core.node.defaultnodesettings.DefaultNodeSettingsPane;
import org.knime.core.node.defaultnodesettings.DialogComponentBoolean;
import org.knime.core.node.defaultnodesettings.DialogComponentColumnNameSelection;
import org.knime.core.node.defaultnodesettings.DialogComponentString;
import org.knime.core.node.defaultnodesettings.SettingsModelBoolean;
import org.knime.core.node.defaultnodesettings.SettingsModelString;

/**
 * <code>NodeDialog</code> for the "Concatenate2Columns" Node. This node
 * concatenates two columns.
 *
 * This node dialog derives from {@link DefaultNodeSettingsPane} which allows
 * creation of a simple dialog with standard components. If you need a more
 * complex dialog please derive directly from
 * {@link org.knime.core.node.NodeDialogPane}.
 * 
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeDialog extends DefaultNodeSettingsPane {
	
	static final String CFGKEY_COL1 = "column1";
	static final String CFGKEY_COL2 = "column2";
	static final String CFGKEY_NEW_NAME = "new_name";
	static final String CFGKEY_REMOVE_SOURCE_COLUMNS = "remove_source_columns";

	static final String DEFAULT_COL1 = "";
	static final String DEFAULT_COL2 = "";
	static final String DEFAULT_NEW_NAME = "Concatenate";
	static final boolean DEFAULT_REMOVE_SOURCE_COLUMNS = false;

	/**
	 * New pane for configuring Concatenate2Columns node dialog. This is just a
	 * suggestion to demonstrate possible default dialog components.
	 */
	@SuppressWarnings("unchecked")
	protected ConcatenateTwoColumnsNodeDialog() {
		super();

		addDialogComponent(
			new DialogComponentColumnNameSelection(
				createFirstColumnModel(), 
				"First column:", 
				0, 
				StringValue.class
			)
		);
		
		addDialogComponent(
			new DialogComponentColumnNameSelection(
				createSecondColumnModel(), 
				"Second column:", 
				0, 
				StringValue.class
			)
		);
		
		addDialogComponent(
			new DialogComponentString(
				createNewColumnNameModel(), 
				"New column name:"
			)
		);
		
		addDialogComponent(
			new DialogComponentBoolean(
				createBooleanModel(), 
				"Remove source columns"
			)
		);
	}
	
	 /**
     * @return settings model for first column selection
     */
    static final SettingsModelString createFirstColumnModel() {
        return new SettingsModelString(CFGKEY_COL1, DEFAULT_COL1);
    }
    
    /**
     * @return settings model for the second column selection
     */
    static final SettingsModelString createSecondColumnModel() {
        return new SettingsModelString(CFGKEY_COL2, DEFAULT_COL2);
    }
    
    /**
     * @return settings model for the new appended column name
     */
    static final SettingsModelString createNewColumnNameModel() {
        return new SettingsModelString(CFGKEY_NEW_NAME, DEFAULT_NEW_NAME);
    }
	
	 /** 
	  * @return settings model for check box whether to remove source columns. 
	  */
    static final SettingsModelBoolean createBooleanModel() {
    	return new SettingsModelBoolean(CFGKEY_REMOVE_SOURCE_COLUMNS, DEFAULT_REMOVE_SOURCE_COLUMNS);
    }
	
}
