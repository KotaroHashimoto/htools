package org.knime.workshop.solution.exercise03_c;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpec;
import org.knime.core.data.DataColumnSpecCreator;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.StringValue;
import org.knime.core.data.def.DefaultRow;
import org.knime.core.data.def.StringCell;
import org.knime.core.node.BufferedDataContainer;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;
import org.strings.concatenate.StringConcatenator;

/**
 * This is the model implementation of Concatenate All String Columns. This node
 * concatenates all string columns and adds the result to the input table.
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateAllStringColumnsNodeModel extends NodeModel {

	/**
	 * Constructor for the node model.
	 */
	protected ConcatenateAllStringColumnsNodeModel() {
		super(1, 1);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		DataTableSpec outputSpec = createOutputSpec(inSpecs[0]);
		return new DataTableSpec[]{outputSpec};
	}
	
	private DataTableSpec createOutputSpec(final DataTableSpec inSpec) throws InvalidSettingsException {
		String concatenateColumnName = "Concatenate";
		DataColumnSpec concatenateColumnSpec = 
			new DataColumnSpecCreator(
				concatenateColumnName, 
				StringCell.TYPE
			).createSpec();
		return new DataTableSpec(inSpec, new DataTableSpec(concatenateColumnSpec));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected BufferedDataTable[] execute(final BufferedDataTable[] inData, final ExecutionContext exec)
			throws Exception {
		DataTableSpec inTableSpec = inData[0].getDataTableSpec();
		DataTableSpec outputTableSpec = createOutputSpec(inTableSpec);
		BufferedDataContainer dataContainer = exec.createDataContainer(outputTableSpec);

		int nrInputColumns = inTableSpec.getNumColumns();
		boolean[] isStringCompatible = new boolean[nrInputColumns];
		for (int i = 0; i < nrInputColumns; i++) {
			DataColumnSpec columnSpec = inTableSpec.getColumnSpec(i);
			isStringCompatible[i] = columnSpec.getType().isCompatible(StringValue.class);
		}
		
		int nrOutputColumns = nrInputColumns + 1;
        for (DataRow row : inData[0]) {
            // Copy cells to new row
        	DataCell[] copyRow = new DataCell[nrOutputColumns];
            for (int j = 0; j < nrInputColumns; j++) {
                copyRow[j] = row.getCell(j);
            }
            
            // Collect all string cells
            List<String> allStrings = new ArrayList<>();
            for (int i = 0; i < nrInputColumns; i++) {
            	DataCell cell = row.getCell(i);
            	if (!cell.isMissing() && isStringCompatible[i]) {
            		String str = ((StringValue) cell).getStringValue();
            		allStrings.add(str);
            	}
            }
            
            String delimiter = ", ";
            String concatenatedString = StringConcatenator.concatenate(allStrings, delimiter);
            copyRow[nrOutputColumns -1] = new StringCell(concatenatedString);
            
            dataContainer.addRowToTable(new DefaultRow(row.getKey(), copyRow));
            exec.setProgress(dataContainer.size() / (double) inData[0].size());
        }
        dataContainer.close();
        return new BufferedDataTable[]{dataContainer.getTable()};	
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

}
