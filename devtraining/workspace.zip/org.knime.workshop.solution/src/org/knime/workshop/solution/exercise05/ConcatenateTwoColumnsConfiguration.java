package org.knime.workshop.solution.exercise05;

import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;
import org.knime.core.node.util.CheckUtils;

public class ConcatenateTwoColumnsConfiguration {
	
	public static final String CFG_KEY_COL1 = "first_column_name";
	public static final String CFG_KEY_COL2 = "second_column_name";
	public static final String CFG_KEY_NEW_NAME = "new_name";
	
	public static final String DEFAULT_COL1 = "";
	public static final String DEFAULT_COL2 = "";
	public static final String DEFAULT_NEW_NAME = "Concatenate";
	
	private String m_firstColumnName;
	private String m_secondColumnName;
	private String m_newColumnName;
	
	public ConcatenateTwoColumnsConfiguration() {
		m_firstColumnName = DEFAULT_COL1;
		m_secondColumnName = DEFAULT_COL2;
		m_newColumnName = DEFAULT_NEW_NAME;
	}
	
	public String getFirstColumnName() {
		return m_firstColumnName;
	}
	
	public void setFirstColumnName(String firstColumnName) {
		m_firstColumnName = firstColumnName;
	}
	
	public String getSecondColumnName() {
		return m_secondColumnName;
	}
	
	public void setSecondColumnName(String secondColumnName) {
		m_secondColumnName = secondColumnName;
	}
	
	public String getNewColumnName() {
		return m_newColumnName;
	}
	
	public void setNewColumnName(String newColumnName) {
		m_newColumnName = newColumnName;
	}
	
	public ConcatenateTwoColumnsConfiguration saveSettingsTo(NodeSettingsWO settings) {
		settings.addString(CFG_KEY_COL1, m_firstColumnName);
		settings.addString(CFG_KEY_COL2, m_secondColumnName);
		settings.addString(CFG_KEY_NEW_NAME, m_newColumnName);
		return this;
	}
	
	public ConcatenateTwoColumnsConfiguration loadInDialog(NodeSettingsRO settings) throws InvalidSettingsException {
		m_firstColumnName = settings.getString(CFG_KEY_COL1, DEFAULT_COL1);
		m_secondColumnName = settings.getString(CFG_KEY_COL2, DEFAULT_COL2);
		m_newColumnName = settings.getString(CFG_KEY_NEW_NAME, DEFAULT_NEW_NAME);
		return this;
	}
	
	public ConcatenateTwoColumnsConfiguration loadInModel(NodeSettingsRO settings) throws InvalidSettingsException {
		m_firstColumnName = settings.getString(CFG_KEY_COL1);
		m_secondColumnName = settings.getString(CFG_KEY_COL2);
		m_newColumnName = settings.getString(CFG_KEY_NEW_NAME);
		return this;
	}
	
	public ConcatenateTwoColumnsConfiguration validate(NodeSettingsRO settings) throws InvalidSettingsException {
		String firstColumnName = settings.getString(CFG_KEY_COL1);
		String secondColumnName = settings.getString(CFG_KEY_COL2);
		String newColumnName = settings.getString(CFG_KEY_NEW_NAME);
		
		CheckUtils.checkArgumentNotNull(firstColumnName);
		CheckUtils.checkArgumentNotNull(secondColumnName);
		CheckUtils.checkArgumentNotNull(newColumnName);
		
		return this;
	}

}
