package org.knime.workshop.solution.exercise01;

import org.knime.core.node.NodeDialogPane;
import org.knime.core.node.NodeFactory;
import org.knime.core.node.NodeView;

/**
 * <code>NodeFactory</code> for the "MyFirstNode" Node.
 * My First Node
 *
 * @author KNIME.com GmbH
 */
public class MyFirstNodeNodeFactory 
        extends NodeFactory<MyFirstNodeNodeModel> {

    /**
     * {@inheritDoc}
     */
    @Override
    public MyFirstNodeNodeModel createNodeModel() {
        return new MyFirstNodeNodeModel();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public int getNrNodeViews() {
        return 0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeView<MyFirstNodeNodeModel> createNodeView(final int viewIndex,
            final MyFirstNodeNodeModel nodeModel) {
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean hasDialog() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public NodeDialogPane createNodeDialogPane() {
        return null;
    }

}

