package org.knime.workshop.solution.exercise07;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataCell;
import org.knime.core.data.DataColumnSpecCreator;
import org.knime.core.data.DataRow;
import org.knime.core.data.DataTableSpec;
import org.knime.core.data.DataType;
import org.knime.core.data.StringValue;
import org.knime.core.data.container.ColumnRearranger;
import org.knime.core.data.container.SingleCellFactory;
import org.knime.core.data.def.StringCell;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;
import org.knime.core.node.defaultnodesettings.SettingsModelBoolean;
import org.knime.core.node.defaultnodesettings.SettingsModelString;
import org.knime.core.node.streamable.simple.SimpleStreamableFunctionNodeModel;

/**
 * This is the model implementation of Concatenate Two First String Columns. This node
 * concatenates the two first string columns and adds the result to the input table.
 *
 * @author KNIME.com GmbH
 */
public class ConcatenateTwoColumnsNodeModel extends SimpleStreamableFunctionNodeModel {

	private final SettingsModelString m_col1 = ConcatenateTwoColumnsNodeDialog.createFirstColumnModel();
	private final SettingsModelString m_col2 = ConcatenateTwoColumnsNodeDialog.createSecondColumnModel();
	private final SettingsModelString m_newName = ConcatenateTwoColumnsNodeDialog.createNewColumnNameModel();
	private final SettingsModelBoolean m_removeSourceColumns = ConcatenateTwoColumnsNodeDialog.createBooleanModel();			

	/**
	 * Constructor for the node model.
	 */
	protected ConcatenateTwoColumnsNodeModel() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected DataTableSpec[] configure(final DataTableSpec[] inSpecs) throws InvalidSettingsException {
		ColumnRearranger rearranger = createColumnRearranger(inSpecs[0]);
		return new DataTableSpec[]{rearranger.createSpec()};
	}
	
	/**
	 * 
	 */
	@Override
	public ColumnRearranger createColumnRearranger(final DataTableSpec spec) throws InvalidSettingsException {
		// check user settings against input spec here
		final int[] indices = findSelectedColumnIndices(spec);
		String newName = m_newName.getStringValue();
		ColumnRearranger result = new ColumnRearranger(spec);
		DataColumnSpecCreator appendSpec = new DataColumnSpecCreator(newName, StringCell.TYPE);
		result.append(new SingleCellFactory(appendSpec.createSpec()) {
			@Override
			public DataCell getCell(final DataRow row) {
				DataCell firstCell = row.getCell(indices[0]);
				DataCell secondCell = row.getCell(indices[1]);
				if (firstCell.isMissing() || secondCell.isMissing()) {
					return DataType.getMissingCell();
				}
				StringValue firstValue = (StringValue) firstCell;
				StringValue secondValue = (StringValue) secondCell;
				return new StringCell(firstValue.getStringValue() + "+" + secondValue.getStringValue());
			}
		});
		if (m_removeSourceColumns.getBooleanValue()) {
			result.remove(indices);
		}
		return result;
	}
	
	private int[] findSelectedColumnIndices(final DataTableSpec spec) throws InvalidSettingsException {
		String first = m_col1.getStringValue();
		String second = m_col2.getStringValue();
		if (first == null || second == null) {
			throw new InvalidSettingsException("Not configured yet");
		}
		int firstIndex = spec.findColumnIndex(first);
		int secondIndex = spec.findColumnIndex(second);
		if (firstIndex < 0) {
			throw new InvalidSettingsException("No such column in input table: " + first);
		}
		if (secondIndex < 0) {
			throw new InvalidSettingsException("No such column in input table: " + second);
		}
		DataType firstType = spec.getColumnSpec(firstIndex).getType();
		DataType secondType = spec.getColumnSpec(secondIndex).getType();
		if (!firstType.isCompatible(StringValue.class)) {
			throw new InvalidSettingsException("Column '" + first + "' does not contain strings");
		}
		if (!secondType.isCompatible(StringValue.class)) {
			throw new InvalidSettingsException("Column '" + second + "' does not contain strings");
		}
		return new int[] { firstIndex, secondIndex };
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveSettingsTo(final NodeSettingsWO settings) {
		m_col1.saveSettingsTo(settings);
		m_col2.saveSettingsTo(settings);
		m_newName.saveSettingsTo(settings);
		m_removeSourceColumns.saveSettingsTo(settings);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadValidatedSettingsFrom(final NodeSettingsRO settings) throws InvalidSettingsException {
		m_col1.loadSettingsFrom(settings);
		m_col2.loadSettingsFrom(settings);
		m_newName.loadSettingsFrom(settings);
		m_removeSourceColumns.loadSettingsFrom(settings);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void validateSettings(final NodeSettingsRO settings) throws InvalidSettingsException {
		m_col1.validateSettings(settings);
		m_col2.validateSettings(settings);
		m_newName.validateSettings(settings);
		m_removeSourceColumns.validateSettings(settings);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void reset() {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void loadInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void saveInternals(final File internDir, final ExecutionMonitor exec)
			throws IOException, CanceledExecutionException {
	}

}
