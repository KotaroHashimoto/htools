package org.knime.workshop.solution.exercise03_b.datatype.gps;

import org.knime.core.data.DataType;
import org.knime.core.data.StringValue;

public class GPSDataCell extends org.knime.core.data.DataCell implements GPSDataValue ,StringValue{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8323996875779899476L;
	private double longitude;
	private double latitude;
    public static final DataType TYPE = DataType.getType(GPSDataCell.class);

	public GPSDataCell(double longitude, double latitude) {
		this.longitude = longitude;
		this.latitude = latitude;
	}

	@Override
	public String toString() {
		return getStringValue();
	}

	@Override
	protected boolean equalsDataCell(org.knime.core.data.DataCell dc) {
		if (dc instanceof GPSDataCell) {
			GPSDataCell other = (GPSDataCell) dc;
			if (other.getLatitude() == getLatitude() && other.getLongitude() == getLongitude()) {
				return true;
			}
		}
		return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getStringValue() {
		return "[" + longitude + "," + latitude + "]";
	}

	@Override
	public double getLongitude() {
		return longitude;
	}

	@Override
	public double getLatitude() {
		return latitude;
	}

}
